## apssync
- robust, scalable graphql intergrface for app dev
- combines data from multiple sources like ddb and lambda
- enables data interaction for dev via graphql
- graphql - data language that enables apps to fetch data from servers
- seamless integration with react, react native, ios and android

> graphql, detch app data, devalarative coding, frontend app data fetching
>
> managed graphql interface for any frontend