## lambda

- serverless compute service - run code without provisioning underlying servers
- runtime
- permissions
- networking -  define the vpc, subnet, sec groups
- resources - available memory, cpu, ram
- trigger - define a trigger for that lambda

> add features to AWS - lambda
>
> do anything that istn built in -lambda
>
> 10 gb ram and 15 mins
>
> major role in aws  ecosystem
>
> can run inside or outside a vpc
>
> ansurre you attacha ole
>
> any aws api call