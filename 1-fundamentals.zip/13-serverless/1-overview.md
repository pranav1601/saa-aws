## serverless

* focus on code and leave the managedment of the compute architecture behind

## benefits

- ease of use
- event based- not runnin 24/7
- billing  - pay as you go - only pay for the length os the runtime
- lambda(run code), fargate(containers)

> move away from unmanaged
>
> select answer that uses lambda fargate contianers instead of ec2
>
> app for containers or ec2?
>
> app aws specific?
>
> how long does code neeed to run?