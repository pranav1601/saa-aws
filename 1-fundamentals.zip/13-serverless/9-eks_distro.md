## eks-d

- kubernets distribution based on and used by amazon eks
- same version and dependency deployed by amazon eks
- dfferences - fully managed by user unlike amazon eks, which is managed by aws
- eks - d can runn anywhere in the cloud, on premise or anywhere
- user fully responsible for upgrading and managing your platforms

> self managed kubernetes deployment - eks d
>
> uses - when need to run versioned deployments of clusters outside of AWS managed service