## eventbridge

- serverless eventbus
- pass events dfrom a source to endpoint

## creating a rule

- pattern - invoked on an event or scheduled
- slect event bus - aws-based event/custom event or a partner
- select your target - what happens when veeent happens? trigger lambda? point to sqs queue? email?
- tag -everything

> integral for serverless
>
> api call can trigger lambda functins
>
> eventbridge/cloudwacth events
>
> fastest way to react to events