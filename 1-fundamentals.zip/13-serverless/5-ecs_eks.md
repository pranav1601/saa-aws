## container problems

- diffucilt to manage multiple containers and resources for them

## ECS

- management of containers - manage thousands of container, apprpriately place containers and keep them online
- elb integration - can be registered with load balancers as they come online and go offline
- role integration - indivudial role attahced to them
- ease of use
- only works in AWS - limitation

## kuberentets

- open source
- container orchestration
- on premise and cloud

![ecs vs eks](../images/ecs_eks.png)

> ecs is preferred
>
> open source, kuberentes, on premise - kuberentes
>
> generally favour aws designed  services
>
> open source - eks
>
> great for one off or loing running applications