## datasync

- agent based solution for migrating on premise storage to aws
- easily move data between nfs and smb shares and aws storage solutions
- 

![datasync](../images/datasync.png)

> datasync - one time migration
>
> sotrage gateway - continuous sync(but sstill can be used to migrate)
>
> primarily one time migration
>
> agent needs to be installed on the arch on user end
>
> s3, efs, fsx are supported locations