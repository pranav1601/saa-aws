## applicaition discovery service

- helps plan migrations to aws via collection of usage and configuration data from on premises servers
- integrates with aws migration hub, simplifying migrations and tracking migration statuses
- help easily view discoered server, group them by application and track each application migration

## disovery types

- agentless - agentless collector. OVA file within vmware vcenter. Idenitfies hosts and vms in vcenter. collected ip, mac, resoruce allocation and hostname. Colllects utilization data metric
- agent based - deploy application disovery agent. rach vm and physical server. installer for windows and linux. static config data, time-serioes performance info, netowkr connection and os processes

## applicatino migration service - MGN

- automated lift and shift to migrate applications
- allows physical, virtaul or cloud servers to avoud cutover windows or disruptions
- replicate source servers into aws for non disruptive cutovers
- replicates source server into aws, automatically conversta and launches an aws to migrate quickly

## rto and rpo

- recovery time objective  - typicalluy just mins, dependent on os boot time
- recovery point objective - measured in ht esub second range
- helps t revocer at any ppint during migration

> 