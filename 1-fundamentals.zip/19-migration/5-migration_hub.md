## migration hub

- track app migration to aws
- integrates with sms and dms
- gui tool

## server migration service

![sms](../images/sms.png)

## database migration service

![dms](../images/dms.png)

> dms -db shifting, sms - shfiting vm as AMI
>
> all app migration needs
>
> focus on asnweres that include doing a complete migrations 