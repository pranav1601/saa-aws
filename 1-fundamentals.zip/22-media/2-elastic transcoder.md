## elastic transcoder

- covert media files from original soutce format into versions that are ptmized for various deviees succh as mobiles, tbelets

## uses

- easy to use
- elastically scalable

> transcode/ convert medial file to particula r format for device - transcoder