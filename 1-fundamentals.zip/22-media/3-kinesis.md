## kinesis video streams

- stram content fomr large number of device to aws and then ruyn alytics, ML, playback and other procesing
- scalles elastically
- stores, encrypts, stores data
- accessible via API

## uses

- smart home - cctv to montor
- smart city
- industrial automation - ingest time encoded data

> video streaming at scale - kinesis streams