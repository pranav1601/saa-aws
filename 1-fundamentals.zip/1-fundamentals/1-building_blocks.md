> 24 regions, 77 availability zones

## Availability zone

> data center -> building filled with servers
> 
> multiple discrete data centers

## Region

> geographical zone with 2 or more availability zones

## edge location

> endpoints used by AWS for caching information

>more edge locations than regions

* consists of cloudfront -> Amazon's CDN(content delivery network)
* closer to user
