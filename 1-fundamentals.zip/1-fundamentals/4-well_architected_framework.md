## 1. operational excellence

* running and monitoring business value
* improving processes and procedures

## 2. performance efficiency

* using IT and computing resources efficienty
  
## 3. security
* protecting information

## 4. cost optimization
* avoiding unnecessary costs

## 5. reliability

* workload performs its intended function correctly and consistently
  
## 6. sustainability
* minimizing env impact of running cloud workload

read whitepaper before the exam