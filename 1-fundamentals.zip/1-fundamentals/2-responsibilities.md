## shared responsibility

### Amazon
* physical security of data centers
* hardware, network, storage, software, hypervisor 
* services
* patching db servers/OS

### User
* security in the cloud
* IAM
* config of OS
* network/firewall
* client side and server side encryption
* network traffic

> encryption is a shared responsibility

Can you do this on your own in the console? yes? then your responsibility else AWS' responsibility