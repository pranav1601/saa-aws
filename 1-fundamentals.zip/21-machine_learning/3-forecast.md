## time sereis data

- data points logged over period od time allowing tracking of data
- done by IOT, analytics,devops apps

## forecast

- time series forecasting that uses ML and built to give important business insights

## uses
- iOt
- anyltics
- devops

> analyse time series data and make predictiin - frecast
>
> store time seris - time streams