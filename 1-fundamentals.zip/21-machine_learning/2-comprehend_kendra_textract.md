## comprehend

- uses NLP to understand meaning and sentiment of text
- automate understanding whether people saying poisitive or negative
- way of automating comprehension at scale

## uses

- call center analsysi - positive or negative with staff. can be used with transcribe
- index and search product reviews - create indexes and automate your product reviews to detect whether peple are happy with your products or sevices or not
- legal briefs management - search all contracts and for examples of recent court case decesions
- finanacial docs - insurance companies can automate insturance clauiims and process where cmmmon claims are comming from

## kendra

- create intelligent search service
- enterprise search apps can bridge different info such as s3 bucket, file server, webistes allowing enterprise to have al, data intelligently in one place

## uses

- accelarate research and development - previous reseahch papers by scientiests scattered over the place such as s3, buckets, db
- improve customer interactions - better understand what cusotmers are asking and then return more relevant answers
- minimize regulatory and compliance risks - use ML to automate the research of new regulation that may impact your business, such as new ISO requirements, HIPAA or pci compliant policices
- employee productivity - having data searchable in onoe place, producitvity increase by ensuring staff are not spending hours trying to fin the right data

## textract

- use ML to extract text, handwriting and data
- beyonf OCR - uses ML and OCT and process text, handwringitng, tables and more with no manual intervention
- can quickly turn text into data, which can be stored in db or s3

## uses

- financial services - customers filling application by hand
- health care - health usurance claims can involve handwriting
- public sector - tax returns completed by accountants or general members done by hand

> intelligenet search service using unstructured text - kendra