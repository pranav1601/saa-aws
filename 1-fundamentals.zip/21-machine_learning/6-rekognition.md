## rekogintion

- computer vision automates pictures and video using deepl learning and neural network
- use these pictures for labels

## uses

- conent moderation - check if nothing violent
- face detection - automatically recognze faces
- celebrity recognition
- streaming video event detection - recognize people, animals and faces

> content moderation using AI - rekognition