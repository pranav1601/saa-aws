## translate

- languiage transaltion automatoin
- depp learning and neual network

## uses

- highly accurate and continously improving
- easy to integrate to app using API
- cost effective compared to hirng humans
- scalable

> translate language - translate