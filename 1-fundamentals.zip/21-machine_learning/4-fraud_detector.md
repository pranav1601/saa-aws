## fraud detector

- AI serrvvice to predict fraudin data
- create fraud detection ML model based on your data. quicly automate this prcoess aas well

## use cases

- suspsiciosus online payments
- detect new account fraud
- stop users from automating free trial accounts so they get indefinite free service
- improve account takeover detections - illegitmatite user hijacks a legitemate users account

> fraud detection ML model customizable by your data - fraud detector