## transcribe

- convert speech to text. 
- subtitles

## uses
- convert audio and video files to text

## lex

- build converstational interfaces in app using natural language models
- when chatting with bot

## uses
- virtual agents and voice assistants
- automate informational responses
- improve producitivtity with app bots
- automate contact center scripts

## polly

- convertdts text ot life like speech
- create apps to talk to and interact using variety of languages and accents

## uses

- content creation

> alexa - mixture of these 3 services - transcribe convertd speech to text, lex understands text and tells what to respond, polly replies
>
> caption -transcribe
>
> converstational chatbot - lex
>
> text to speech - polly