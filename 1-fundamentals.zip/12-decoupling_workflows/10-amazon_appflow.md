## amazon appflow

- echange data betwwen SAAS apps and aws service
- oull ata from thir party saas and store them in amazon s3
- bi directional with limited combinations

## cncepts 
- flow - transfers datta between source and destination
- data mapping - how your source data is stored
- filters - which data is transferred
- trigger - how the flow is started

![appflow](../images/appflow.png)

## uses

- transferring salesforce records to reshift
- analysizng slack conversation in s3
- migrate help desk support tickets to snowflake
- transfer aggregate data to s3 - upto 100 gb