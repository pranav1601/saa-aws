## device farm

- app testing service for testing and interaction with android, ios and web apps.
- useable on actual phones and ttablets hosted by aws

## 2 methods

- automated - upload scrpts or use built in tests for automated parallel test on mobile devices
- remote access- swipe, gesture and interact with devices in real time via web browsers

> app testing on mobile devices in aws, needing actual phone -device farm