> very few of services seen in exam
>
> Amazon pinpoint most asked