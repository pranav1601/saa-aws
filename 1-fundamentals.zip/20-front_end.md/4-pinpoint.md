## pinpoint

- engage with cusotmer through a variety of different messaging channels
- for marketers, business users and sometimes devs

## features

- projects - collection of information, segments, campaigns and journeys
- channels: the platform where you intend to engage your audience segments
- segments - dynamic or importsed- designates which users receive specific messages
- campaigns- initiatives engaging specific audience segments using tailored messages
- journeys - customized, multi step engagements
- message templates - content and setting for easily reusing repeated messages
- machine learning - leverage machine learning models to predict user patterns

## uses

- marketing - promoting products - emails, sms, push notifs
- transactions - messages to customers after transactions - order confirmation, shipping notifications
- bulk - messages targeted to millions of people

> marketing, user engagements, sending emails, ML for user engamgement predictions - pinpoint