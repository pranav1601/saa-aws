## permissions

-> effect
-> Action
-> resource

## best practice
* add user to a group
* attach policy to a group
* user inherits the permissions from the group
  
> all in global level, not region based

> assign permissions using IAM policy docs