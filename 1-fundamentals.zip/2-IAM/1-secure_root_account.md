## IAM

* create users, permissions, groups, roles and control access to AWS resources

## Root account

* full administrative access
* important to secure

## securing root account
* enable MFA
* create admin group for admins and assign appropriate permissions to this group
* create user accounts for admins
* add users to admin group
* avoid logging in from root account 