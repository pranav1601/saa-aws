## pricing for ec2

* on demand - pay per hour or second
* reserved - 1 or 3 years upfront pay up
* spot - unused instances
* dedicated - specific dedicated ec2 servers

## dedicated hosts

* compliance - regulatory requirements that may not support multi tenant virtualization
* on demand can be purchased on demand
* licensing - great for licesnsing that does not support multi tenanc or cloud deployments
* reserved - can be purchased as reservation for up to 70% off the on demand price

> special licensing requirement -> dedicated hosts -> physical server with ec2 instance capacity fully dedicated you your use. use existing per socket , per core, per VM software licenses including windows server, Microdoft swl server and suse linux enterprise server.