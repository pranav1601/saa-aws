## outposts

* allows youo to ahve AWS servides in your data center -> brings AWS to on premis
* 1U and 2U servers upto 4U racks and multiple racks deployments.

## benefits

* hybrid cloud where you use AWS service in on premise
* AWS can manage infra for you
* no teeam required to look into outposts infrastruture
* consistency -> bring AAWS management cnsole, API and SDK in your data center allowing uniform consistency in hybrd environment

## outposts rack

* hardware -> 42U rack upto 96 racks
* services -> AWS compute, storage, db, other services locally
* gives same AWS infra, services, and APIS in your own data center.

## outposts server

* hardware -> individual servers in 1U or 2U form factor
* use case -> for small space requirements such as retail stores, branch offces, healthcare provder locations or factory floors
* results -> provides local compute and networking services

## process

* order outposts config
* AWS staffs comes on stite to install andeploy hardware, including power, networking, connectivity
* launch instances on your outpost on site
* start buildining you outpost env

> extending AWS to datacenter
>
> outpost rack for large deployments
>
> outpost server for small deployments