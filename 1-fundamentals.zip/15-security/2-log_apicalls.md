## cloudtrail

- increases visibility by logging user actions on console
- users, action, ip, time
- like a cctv
- loggged - metadata, identitiy, time, source ip, request parameters, response elements returned y the service
- incident investigation
- real-time intrusion detection
- indusrety and regulatory compliance
- store logs in s3