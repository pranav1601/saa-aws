## detective

- analyze, nvestigate and idenify potential sec issues or supsiciois activiteis
- uses ml, statistics, graph theory

## sources

- vpc flow logs
- ct logs
- eks audit logs, guardduty findings
- creates overview of users, resources and interaction between them over time

## uses

- triage sec finds. quickly asssess if real or false positive
- threat hunting - in comparison to root cause analysis can go threat hunting

> root cause, grapht theory - detective
>
> inspector - automated vulnerability management service that continually scan ec2 and container workloads for vulnerablilities