## certificate manager

- create and manage public and private ssl certificate
- integrate with elb, cf distibutions, api gateway allowing easy manae and depoy of ssl certificates
- cost - no need to pay for ssl certificates to thir parties
- automated renewals and deployment, automatically rotates
- easy to setup, and removes manual process

> free service that saves time and mnoney