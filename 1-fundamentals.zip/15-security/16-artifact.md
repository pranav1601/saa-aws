## artifact

- single sources to get the compliace related information such as aws security and compliance reports or select online agreements - used for downloading
- huge compliance reports available.

> audits and need to download compliance reports - artifact