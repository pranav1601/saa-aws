## shield

- free ddos protection - elb, cloudfront, route 53
- protects afainst syn/udp and other 
- layer 3 or layer 4 attacks

## shield advanced

- enhanced protection against alrger and sophisticated attacks
- always on, flow based monitoring of network traffic and active app mointorring to provide real time notification of ddos attacks
- 24/7 access to ddos response team to help manage and mitigate appplication layer ddos attacks
- protects your aws bill against higher fees due to elb, cloudfront, route 53 spikes during ddos attacks

## cost

- shield adv - 3000 dollars per month
- shield 0 free

> shield protects under layer 3 and layer 4 only
>
> application layer attacks - WAF