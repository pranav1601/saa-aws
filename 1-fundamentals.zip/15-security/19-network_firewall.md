## network firewall

- physical firewaall to vpc - network firewall
- managed infrastructure
- complete control over network traffic
- block outbound smb reqwuests

## benefits

- physical infra in AWS
- no management overhead
- works with firewall manager - centrally handle
- provide intruision prevention sysystems (IPS)

## uses

- filter internet traffc - ACL rules, rpotocol detection, intrusion preventiion
- filter outbound traffic - provide urlm, ip, cntent bases outbound traffic. Help stop possible data loss and block known malware communications
- uinspect vpc to vpc traffic - across multiple accounts

> filtering network traffic / IPS/ hardware firewall - AWS network firewall
> 