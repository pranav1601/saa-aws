## security hub

- single place to view all sec alerts - guarduty, inspecorm macie, firewall amanger
- across multiple account

## uses

- consunct cloud security posture - automated check with CIS or PCI to help reduce risks
- correlate sec finding to discover new insights - aggregare all sec finding in onve places allowuing sec staff to more easily identify threats and alerts

> single place to view all sec alerts acroos multiple services and accounts - security hub