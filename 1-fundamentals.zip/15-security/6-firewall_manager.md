## firewall manager

- sec managment service in a single pane of glass
- alloows to centrally set up and manage firewall rules acrros multple accounts
- new waf rules for alb, gateway, cloudfront
- mitigate ddos attacks using aws shield

## benefits

* simplify firewalls rules across acounts
* ensure compliance of existing and new applications

> multiple accounts and secured centrally - firewall manager