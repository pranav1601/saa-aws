## parameter store

- aws systems manageger that provides secure, hierarchial storage for config data management and secrets management
- passwords, db string, ami ids, license code - plain or encrypted
- free

## limits 

- 10000 limit to parameters
- no rotation

> limit cost - parameter\
>
> more than 10000/key rotation/ generate passwords using CFT - secerets manaager