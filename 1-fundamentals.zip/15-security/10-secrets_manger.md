## secrets manager

- secerules stores, encrypts and rotate credentials
- encryption in transit and rest
- retrieve secret programitically
- reduces risk of credentials being compromised
- rds creds
- any secret as key value pair
- if enable rotation, secret manager rotates it once to check
- ensure app is not using ambedded credentials

> 