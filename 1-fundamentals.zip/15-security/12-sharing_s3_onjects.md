- all objects in s3 private by default
- can share with other by presigned url using own sec cred to grant time limited permission to download objects
- presigned url - sec creds, s3 name, object key, http method

## access 
- anyone iwht presigned url can access

## presigned cookies

- provide multiple restricted files
- cookie stores on user's computer
- able to brow the entire contenets

> share private s3 files- presigned url