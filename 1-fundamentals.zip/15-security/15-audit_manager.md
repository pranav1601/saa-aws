## audit manager

- continously audit aws usage and stay compliany with industry standards
- automated service that produces audiotrs for pci compliace, gdpr and more

## uses

- transition from manual to automated evidence collection
- continous auditing and compliace
- internal riska assessments

> hipaas or gdpr, continouus auditing - audit manager