## vertical scaling

* use the highest configuration for a service
* limit to how much it can scale

## horizontal

* no limit
* redundancy
* use mulitple instances

## 3 w of scaling/exam tips

1. what - what do we scale
2. where do we scale - web server? database?
3. when do we scale? cloudwatch alarms to tell us when to scale

> always choose highly available solutions
>
> always hould be cost effective
>
> switching database might fix the problem