## well architected framework

- provides consistent process for measure cloud arch
- enables assistance with documention workloads and arch
- guides for making workloads reliable, secure, efficient and cost effective
- measure workloads against years of aws best practices
- itnended for special audiences, such as technical teams, cto, arch, operation team

> used fro measuring current workloads again established aws best practices