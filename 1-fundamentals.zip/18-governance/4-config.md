## config

- inventory management acnd control tools
- shows hstory of infrastricture along with creating rules to make sure it conformms to the best practices laid out
- query resources type, tag and even see deleted infra - easily discover arch in account
- rules can be created to flag when something is wrong - alerted when a rule is violated
- history - when what change was made

> enforcing standards - config
>
> setup rules and automatic remediations
>
> you can use autoamtion docs or lambda to enforce standards
>
> rolll up allyourresults to single region