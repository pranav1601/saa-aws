## aws budgets

- allows orgs to plan and expectation around cloud costs
- seet alerts

## 4 types

1. cost budget - how muich are we spending
2. usage budget - how much are we using
3. reserveation budgetts - are we being efficient with RI
4. saving plans budget - is what we are oing cvered by saving plans?

2 budgets free per month

> create budget
>
> create ubdget using tags as filter
>
> use cost exoplkoerer to create fine grained budgets