## aws control tower

- set up and govern aws multi account env
- automates account creation and security controls via other aws services
- extends organizations to prevent governance drift and leverage different guardrails
- users can provisson new aws accounts quickly using central admin established compliacne policies
- quickest wat to create and manage a secure compliant multia account env based on best practices

## feaures

- landing zone - well arch, multi account env based on compliance and sec best practives
- guardrails - high level rules provising continuous governace for the aws env
- account factory- configurale account template for standardizing pre pproved configs of new accounts
- cft stackset- automated deployments of templates deploying repeated resources for governances
- shared accounts - three accounts used by control tower created during landing zone creation

![guradraisl](../images/guardrails.png)

![control tower](../images/controltower.png)

> governance and ustomate account deloyment - control tower
>
> 3 shared accounts - maangement, log, audit
>
> automated multi account govertnance, guardrails, account orchestration, goverened user account proisioning - control tower