## cross account role access

- as acounts ncreas - need to set up cross account access
- duplicating iam accounts creates security vulnerability
- cross-account role access gives the ability to set up temorary access that can be easily controlled
- naytime creds are mentioned - scan answers for looking roles

preferred to create cross account roles rather than IAM accounts

> auditing - temporary employees get role access
>
> temporary - never permanent