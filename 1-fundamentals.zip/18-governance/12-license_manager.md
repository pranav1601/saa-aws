## license manager

- simplifies managing software with different vendor
- centralised - centrally manage license across aws accounts  and on premise
- usage limits - control and visibility into usage of licenses and enabling license usage limits
- overages - reduces overages and penalties via inventory tracking and rule based controls for coonsumptiopn
- versatile - supports any software based on vcpu, physcial cres, sockets and number of machines 

> license management simpler
>
> aws hosted license management, hybrid env license management, preventing license abuse