## budget

- know where money is going

## cost exploerer

- tool to visualize costs , allocate based on factors, including resource tags
- service - easily break down costs on a service by service bsis
- time - what was bill last month, how much next month
- filter - where spend coming from, filter tags etc

> cost - cost exploerer
>
> filter based ont atags, regions etc
>
> track budget and spend
>
> tags are one of the most important ways to track spend
>
> cost explorer and budgets go hand in hand