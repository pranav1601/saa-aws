## directory service

- managed version od active directory
- run AD on aws without any heavy setup
- managed microsoft AD - entire AD suite - easily build out AD in AWS
- AD connector - creates a tunnel bettwen aws and your on premises AD
- simple AD - standalon directory powered by linux samba active directory compatible server

> 2 types of directroy server - managed mcirosoft ad and ad connector
>
> use directory serevcce over ec2 instances for AD
>
> it is okay to leave AD on premise - frequently in exams
>
> user management requires right tool, make sure you are using aws sso for internaal user management and cognito for external
>
> 