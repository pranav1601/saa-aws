## aws ram

- resource access manager
- share resources with other accounts and witihin organization.
- share resources rather than creating duplicates
- transit gateway
- vpc subnets
- lcense manager
- route 53 resolver
- dedicated hosts

> ram vs vpc peering - share resources within same region - RAM; across regions - vpc peering. if no RAM vpc peering s a great option
>
> vpc peering - excels when you are connecting 2 separate networks