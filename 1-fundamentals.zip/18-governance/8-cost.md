## cost and usage reports

- aws cur
- comprehensive set of cost and usage data for aws spending
- publish reports to s3 for centrralised collection
- break costs down by time span, service and resource or by tags
- updates reports in s3 buckets once a day using csv formats
- integration - integrate with athena, redshift, or quicksight

## uses

- used by eintire OU or ndividual member accounts
- track saving plans
- montirir on deman capacity reservations
- breaks down aws data transfer charges- external and inter-region
- dive depper into cost allocation tag resource

> comprehensive and detailed view of aws pending
>
> allows centralised storage
>
> detailed cost breakdowns, daily usage reports, tracking savings plan utilizations - cost and usage reports