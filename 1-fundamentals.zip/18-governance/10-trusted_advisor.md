## trusted advsor

- aws managed service
- best practice auditng tool
- scan 5 different parts of account and look for places when one could imporve adoption of recommended best practices

## 5 areas

- cost optimization - soending on resources that arent needed?
- preformance - are your services configured properly?
- security - is arch free of vulnerabilitites
- fault tolerance - protected when something fails?
- service limits - can your arch scale

> automate solution <- focus on awwess
>
> aleerts - SNS
>
> cost- to get mmost useful checks - will need business or enterprise support plan
>
> will not fix only alert
>
> use eventbridge to kick off lambda to solve the problem