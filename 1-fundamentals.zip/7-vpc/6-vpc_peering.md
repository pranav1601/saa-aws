## multiple vpc

* different vpc for diff envronment and may need to nteract with eachother
* connect 1 vpc to another via direct network route
* instance behave as there in one private network
* possible with other aws accounts
* star config - i pc with 4 other

> using private ip adresses
> 
> no overlapping CIDR address ranges