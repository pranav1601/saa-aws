## direct connect

* establish network connection from premise to aws
* reduce cost, increase throughput, more consistent netwrok experience
* dedicated connection:
* * physical ethernet connection
* * can be requsted using console, cli, api
* hosted connection
* * physcial thernet connect that sirect connect partner provisions ono behalf of a customer. customer request a hosten connection by contacting a partner in the aws direct connect partner program.

## vpn vs direct connect

* vpn is slow
* provides private connection but still uses internet

> connects directly to datacenter
>
> stable and reliable
>
> increase throughput workloads