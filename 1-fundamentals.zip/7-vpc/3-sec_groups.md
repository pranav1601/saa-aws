## review

* any connecitivity issue to internet related to sec groups
* virtual firewalls
* to let everything in 0.0.0.0/0
* by default everything blocked
* stateful - if you send request from instance, traffic for that request is allowed to flow in regardless of the rules. if for a port in bound is open then outbound will be open too