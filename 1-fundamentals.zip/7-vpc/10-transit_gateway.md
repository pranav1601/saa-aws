## transit gateway

* connects vpc and on premise network with a central hub
* ends complex peering routes
* transitive peering between 1000 of vpc and data ceners
* hub and spoke
* across multiple rehions
* across multiple aws acoounts using resource access manager

> use route table to limit how vpc talk to one another
>
> works with direct connect and vpn
>
> supports ip multicast - not supported by any other AWS service
>
> simplifying network topology - transit gateway