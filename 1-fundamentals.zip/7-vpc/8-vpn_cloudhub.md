## vpn cloudhub

* multiple sites each with own vpn connection, can use cloudhub to connect those sites together
* hub and spoke model - star
* low cost and easy to manage
* happens over public internet, but traffic between customer gateway and AWS VPN cloudhub is encrypted

![cloudhub](../images/cloudhub.png)