## quantum ledger db

* nosql
* immmutablee
* tranparent 
* cryptographuically verifiable transaction log owned by one authority
* cannot update
* instead update adds

## uses

* cryptocurrencyies
* shipping compains use to track items, boxes , shipping containers, deliveries, etc
* pharma companies use to track createion and distribitui0on of drugs

## use cases

* store financial transactions - complete and accurate record of all financial transactions
* reconcile supppply chain systems - record history of transactoin, provide details of every batch manufactured, shipped, stored and sold from faciltiyi tp store
* maintain claims history - cryptographically verify data integruity to make app resilient against data entry error
* centralise digital records - create complete centralized record of employee detaisls such as payroll

> distractor
>
> not talking about immutable db - donot select qldb