## mongodb

* doc database
* scaling, flexibility,

## amazon doc db

* runs mongodb on cloud
* scales with workloads and safely and durably stores your db information
* no need to manage cluster management, backups or monitoring

> moving mongodb to AWS - mongo on premise ->  AWS db migration service -> amazon documentdb
