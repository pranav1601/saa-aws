## time sries data

* data point logger over series of point to track datatempeatures
* IOT - agriculture- sensors - logs moisuture etc
* analytics - netflix - incomming and outgoing traffic
* devops - apps that change accoriding to users need to scale correctly

## timestreams
* trillion events per data
* 1000 timees faster and 1/10 cost of traditional

>where to store time series data - amazon timestream