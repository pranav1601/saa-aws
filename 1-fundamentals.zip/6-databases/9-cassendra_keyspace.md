## cassendra

* distributed db 
* nosql
* big data solutions
* eg netflix

## keyspace

* apache cassendra db service
* allows to run cassandra workloads on AWS andf is a fully managed db service

## uses

* fully managed
* no patching
* no managing
* serverless
* automatic scaling

> migrating big data cassandra -> keyspaces

