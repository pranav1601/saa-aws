## on demand backup and restore

* full backups at any time
* no impact on performance
* consistent within second and retained unitl deleted
* same region as source table

## point in time recovery

* protects against accidental writes/deletes
* restore in anytime to last 35 day
* incremental backups
* not enabled by default
* latest restorable - 5 minutes in the past