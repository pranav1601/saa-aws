## cloudformation

- declarative prgramming language - json or yaml
- deploy your template - clloudformation will make api calls from your behalf

> immutable arch
>
> pick template and run template to create same arch
>
> hard corded id(eg AMI) can e the reason for templates to fail in different regions
>
> immutable arch preferred