## Paas

- platform as a service
- single stop app delployment
- swploys app, manages it

## elastic beanstalk

- automation - automates all deploments, templatize what your env would look like
- deployments - handle add deployments - upload code, test in staging and deploy to prod
- management - will handle building out the insides of ec2

> simple one stop solution - elastic bean sttalk
>
> bring your code that that is it
>
> PAAS
>
> supports container, windows, linux
>
> generally for simpler web apps only
>
> not serverless - creating and managing standard ec2 arch