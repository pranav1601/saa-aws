## why

- manual is a gamble
- manual - errors

## benefits

- time
- security - easy to prevent security issues
- cnsistency

## sevices

1. cloudforamtion -infra as code
2. elastic beanstalk - drag and drop, align autoscaled web apps
3. system manager - patch, update manage and cofigure ec2 and on premise

> select answer that does not includde manual steps
>
> replace manual with automation
>
> automte>manual
>
> reliable and faster
>
> immutable infra
>
> can you automate?
>
> wha tkind of automation works in this scenario
>
> is autmation repeatable
>
> will this work cross-region or cross-account