## systems manager

- suite of tools deisinged for view, contol, automate both aws arch and on premise
- automation docs - control instances or aws resources
- run command - execute commands on your hosts
- patch manager - manages your app versions
- parameter score - securely store secret values
- hybrid activation - control you on on premise atch using ststem manager
- session manager - remotely connect and interact with your arch
- need to install agent

> support on premise
>
> oatch, update and configure instances
>
> unpaid syadmin
>
> automation docs - usable by aws to enforce arch state. primary methodused in scenarios asking you to cnfigure the onside of ec2 instance