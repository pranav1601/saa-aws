* s3 scales automatically according to demand
* on console in properties of bucket enable static webhosting. supply index page, error page
* url is then created
* add files to upload
* edit bucket policy
* allow everything to access s3:getobject for the arn 

> static website -> s3
> bucket policies->entire bucket public
> static content only
> s3 scales automatically with demand