## lifecycyle management

* automates moving your objects between different storage tiers, maximizing cost effectiveness

## versioning

* enable bucket versioning 
* create lifecycle rule under managmenet

> can ve used with versioning
> can be applied to current versions and previos versions