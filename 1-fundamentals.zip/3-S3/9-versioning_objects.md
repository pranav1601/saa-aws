## versioning

* multpile versions of same object

## advantages

* all versions stores in s3 -> include all writes evn if deletd an obkject
* great backup tool
* once enabled, cannot be disabled,
* integrated with lufercycle rules
* supoorts MFA
* older versions of onject will not be publically acessible

> all versions of object are stored in s3 even if you delete
> good backup
> once enabled, versionoing cannot be disabled
> integrrated with lifecycle rules
> suppots MFA