## access control list

* object acl work on individual object level

## bucket policy

* work on entire bucket

> when bucket is created it is private by default. allow public access on both bucket and its objects in order to make the bucket public
> 
> individual objects are made public using object ACLs
> 
> entire buckets public using bucket policies
> 
> when object uploaded to s3 you will reveive http 200 code
> 