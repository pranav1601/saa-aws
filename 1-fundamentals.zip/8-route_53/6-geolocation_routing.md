## geolocation routing

* routing based on geolocation of users
* european customers to european server

> based on location of users(low latency not priority) - geolocation