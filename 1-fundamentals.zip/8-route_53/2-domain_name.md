## register a domain name

* buy directly from aws
* takes upto 3days
