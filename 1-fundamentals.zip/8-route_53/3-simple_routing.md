## simple routing

* one record with multiple ip addresses
* if supply multivalues, served to the user in random order

> you can only have on record with multiple ip addresses