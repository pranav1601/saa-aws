## route 53 traffic flow

* use this service to build a routing system that uses a combination of geographic location, latency, availability to route traffic
* you can build your route traffic policies from scracth or you can pick a template and custmize it
* all kind of routing archs

## geopromiximity routing 

* only available in traffic flow
* based on geographic localtion of your users and resources
* optionally choose to route more traffic or less by a specific value called bias
* bias expands or cshrinks the size of geographic region from which traffic is routed to resource