## failover routing

* active/passive setup
* primary site - one region, secondary disaster recovery site - other region
* if primary site fails(vhevked via health check), fail over to other site