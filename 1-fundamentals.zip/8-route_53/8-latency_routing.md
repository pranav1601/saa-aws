## latency routing

* traffic sent to ec2 based on lowest latency for user