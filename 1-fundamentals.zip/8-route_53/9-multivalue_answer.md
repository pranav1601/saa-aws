## multivalue answer routing

* configure route 53 to return multiple values, such as ip, in resoponse to dns queries
* also allows you to check the health of each record
* simple routing but health checks built in