## athena

- interacttive query service to anylze data in s3 using sql
- query your data directly in s3 without shifting to db

## glue

- serverless data integration
- perform ETL workloads without managing underlying servers

## athena and glue

![athena and glue](../images/athena%20and%20glue.png)

> serverless sql - athena
>
> only service that allow query data stored in s3
>
> athena and glue are both serverless
>
> glue can design schema for data that can be used by athena