## quicksight

- data visualisation service for BI
- create dashboards

![quicksight](../images/quicksight.png)

> interpreting data and dashboard - quicksight
>
> visualize - quicksight
>
> BI -quicksight
>
> not analyze but visualize