## 3 v of big data

1. Volume - ranges from terabytes to petabytes
2. variety - includes data from a wide range of sources and formats
3. velocity - require speed

## redshift

- petabyte scale data
- very large relational db
- cloud data warehouse
- 16 pb of data
- dont have to splot large data sets
- can use sql and BI tools to interact
- best for BI applications, not replacement of standard rds db

> Bi apps, relational, 16 pb
>
> what kind of db works?
>
> how much data do we have?
>
> is serverless  reuquirements?
>
> how do we optimize costs?
>
> only support single az deploymenets - create multiple clusters in different az but technically seaprate deployments. not highly available by default
>
> 