## etl

- extract
- transform
- load

## emr

- managed big data platform allows to process vast amounts of data such as spark
- AWS's ETL tool

## EMR arch

![emr](../images/emr.png)

> emr is a open source cluster - managed fleet of ec2 running open source apps
>
> use RI and spot to reduce cost
>
> emr used to process and mve data
>
> the arch 
>
> emr made of ec3 instances - means you can employ standard ec22 instance cost saving measures