1. s3 - serverless storage
2. glacier - archiving objects
3. efs - nds for linux instances. centralized storage
4. fsx for lustere- hpc for luinux file ssyustems
5. ebs volumes - persistent stroage for ec2 instances
6. instance sore - epehemeral storage for ec2
7. fsx for windows - file storage for wndows instanaes. centeralized acoss multiple AZs