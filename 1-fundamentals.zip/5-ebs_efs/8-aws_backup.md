## backup

* consoidate your backups across mulitple services

## backup with organizations

* to backup multiple aws account in your org
* centralised control across all aws services in all accounts

## benefits

* central management - central backup console to centralize back across muitluiple aws servcice in mutiple accoutns
* automation - automated backup schedules and retention policies, crreate lifecycle poluicies allowing tou to epire unnecessary backups after a long time
* compl;iance - backup policies can be enforxed while backups can be encrypted both at rest and in transit allowing alignment to compliance. Ausiting is made easy dute to consolidated view of backups across many aws services.

> aws services - ec2, ebs, efs, fsx for lustree, fsx for windows, sotrage agateway
>
> use with orgs for multiple accounts
>
> cnetralized control, automate to lifecycel, better complicance and enforce bakcup policies eg backups are encypyted and audit them once complete.